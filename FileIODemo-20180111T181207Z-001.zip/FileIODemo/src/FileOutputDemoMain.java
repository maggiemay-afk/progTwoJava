
import javax.swing.*;
import java.io.*;
import java.util.*;

public class FileOutputDemoMain {

	public static void main(String[] args) throws FileNotFoundException{
		String fileName;
		String studentName;
		int studentScore, totalScore=0, countOfStudents, averageScore;
		fileName = JOptionPane.showInputDialog("Enter the name of the file that holds student information");
		countOfStudents = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of students in the file"));
		
		
		//On a MAC it should be "/users/w1082952/temp/  
		//On a PC its should be "c:\\temp\\" - NOTE that you need to escape the backslash
		Scanner inFile = new Scanner(new FileReader("/Users/w1082952/Desktop/temp/" + fileName + ".txt")); 
		PrintWriter outFile = new PrintWriter("/Users/w1082952/Desktop/temp/" + fileName + "-out.txt");
		
		for (int i = 1; i <=countOfStudents; i++) {
			studentName = inFile.next();
			studentScore = inFile.nextInt();
			JOptionPane.showMessageDialog(null, String.format("Processing %s\t%d\n", studentName, studentScore), "Processing", JOptionPane.INFORMATION_MESSAGE);
			outFile.format("Processing %s\t%d\n", studentName, studentScore);
			totalScore += studentScore;
		}		
		JOptionPane.showMessageDialog(null, String.format("Number of students processed:\t%d\nTotal Score:\t%d\nAvergae Score:\t%.2f\n", countOfStudents, totalScore, totalScore/ (double) countOfStudents), "Processing", JOptionPane.INFORMATION_MESSAGE);
		outFile.format("Number of students processed:\t%d\nTotal Score:\t%d\nAvergae Score:\t%.2f\n", countOfStudents, totalScore, totalScore/ (double) countOfStudents);
		outFile.flush();
		
		inFile.close();
		outFile.close();
	}

}
