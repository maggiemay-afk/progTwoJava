import geoshapesAPI.*;
import pointAPI.*;


public class PackageDemoMain {

	public static void main(String[] args) {

			MyPoint p1 = new MyPoint(2, 3);
			MyPoint p2 = new MyPoint(5, 6);
			MyPoint p3 = new MyPoint(7, 11);
			
			System.out.println(p1);
			System.out.println(p2);
			System.out.println(p3);
			
			MyRectangle r1 = new MyRectangle(p1, p2);
			MyRectangle r2 = new MyRectangle(p2, p3);

			System.out.println(r1);
			System.out.println(r2);
			
			MyTriangle t1 = new MyTriangle(p1, p2, p3);
			
			System.out.println(t1);
	}

}
