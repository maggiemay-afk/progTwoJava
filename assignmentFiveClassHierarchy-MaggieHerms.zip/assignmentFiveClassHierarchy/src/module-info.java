module assignmentFiveClassHierarchy {
}