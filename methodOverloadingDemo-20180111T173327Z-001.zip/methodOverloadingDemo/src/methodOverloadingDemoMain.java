public class methodOverloadingDemoMain {
	
	public static double findArea(double radius){
		return Math.PI*radius*radius;
	}
	
	public static double findArea(double width, double length){
		return width*length;
	}
	
	public static void main(String[] args) {
		
		double area;
		area = findArea(2.1);
		
		area = findArea(2.2, 3.1);
	}
	
}
