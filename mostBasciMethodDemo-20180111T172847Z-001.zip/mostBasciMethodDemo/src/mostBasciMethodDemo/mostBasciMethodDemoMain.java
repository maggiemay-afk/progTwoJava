package mostBasciMethodDemo;

public class mostBasciMethodDemoMain {
	
	public static void haveANiceDay(){ //function Definition
	     System.out.println("The program is now terminating.");
	     System.out.println("have a nice day!");
	     return;
	}

	public static void main(String[] args) {
		System.out.println("Will call haveANiceDay next");     
		haveANiceDay();  //function call
		System.out.println("Just returned from haveANiceDay function");
		haveANiceDay();
	}
}
