module diceGame {
	requires java.desktop;
}