package primitiveVsReferenceDemo;
import java.util.*;

public class primitiveVsReferenceDemoMain {

	public static void primitiveFun(int x) {
		x = 5;
	}
	
	public static void referenceFun(String y) {
		y = "Hello to you";
	}
	
	public static void referenceFun(StringBuffer y) {
		y.replace(0,  y.length(), "Hello to you");
	}
	
	public static void main(String[] args) {
		int x=1;

		primitiveFun(x);
		System.out.println(x);	
		
		String s1 = "funny";
		referenceFun(s1);
		System.out.println(s1);
		
		StringBuffer s2 = new StringBuffer("funny");
		referenceFun(s2);
		System.out.println(s2);
	}
}
