
public class ScopeOfIdentifiersDemoMain {
	public static void fun(int x, int y){
		
		int a = 2;
		
	 	if (a >= y){
			int b;
			a = 10;
			x = a;
			b = 10;
			c = 10;
			if (a <y) {
				b = 10;
				c = 5;
			}
			
		} else {
			int c;
			a = x;
			c = 15;
		}	
	 	x = 10;
	 	c = 4;
	}	
	public static void main(String[] args) {		
		
		a = 10;
		b = 10;
		x = 10;
		y = 10;
		c = 10;

	}
}
