module assignmentFourDictionary {
	requires java.desktop;
}