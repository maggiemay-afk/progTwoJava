import java.lang.*;

public class PredefinedClassesDemoMain {
	public static void main(String[] args){
		//Using the constants and methods from the predefined Math class 
		//to compute √(𝑥^3+𝑥^2 )

		double x = 2.1, y;
		y = Math.sqrt(Math.pow(x, 3)+Math.pow(x, 2));
		System.out.println(y);
		
	}
}

