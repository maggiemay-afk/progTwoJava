module assignmentOne {
	requires java.desktop;
}